const tmdbService = require('../services/tmdbService');
const User = require('../models/User');
const Movie = require('../models/Movie');
const { validationResult } = require('express-validator');

class MovieController {
  async searchMovies(req, res) {
    try {
      const { query, page = 1 } = req.query;
      
      if (!query) {
        return res.status(400).json({ message: 'Search query is required' });
      }

      const results = await tmdbService.searchMovies(query, page);
      
      // Save movies to database for future recommendations
      const moviePromises = results.results.slice(0, 10).map(async (movie) => {
        try {
          const detailedMovie = await tmdbService.getMovieDetails(movie.id);
          return await tmdbService.saveMovieToDatabase(detailedMovie);
        } catch (error) {
          console.error(`Error saving movie ${movie.id}:`, error);
          return null;
        }
      });

      await Promise.all(moviePromises);

      res.json(results);
    } catch (error) {
      res.status(500).json({ message: 'Failed to search movies', error: error.message });
    }
  }

  async getMovieDetails(req, res) {
    try {
      const { id } = req.params;
      
      let movie = await Movie.findOne({ tmdbId: id });
      
      if (!movie) {
        const tmdbMovie = await tmdbService.getMovieDetails(id);
        movie = await tmdbService.saveMovieToDatabase(tmdbMovie);
      }

      res.json(movie);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get movie details', error: error.message });
    }
  }

  async getPopularMovies(req, res) {
    try {
      const { page = 1 } = req.query;
      const results = await tmdbService.getPopularMovies(page);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get popular movies', error: error.message });
    }
  }

  async getMoviesByGenre(req, res) {
    try {
      const { genreId } = req.params;
      const { page = 1 } = req.query;
      
      const results = await tmdbService.getMoviesByGenre(genreId, page);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get movies by genre', error: error.message });
    }
  }

  async getGenres(req, res) {
    try {
      const genres = await tmdbService.getGenres();
      res.json(genres);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get genres', error: error.message });
    }
  }

  async rateMovie(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { movieId, rating } = req.body;
      const userId = req.userId;

      const user = await User.findById(userId);
      
      // Remove existing rating for this movie
      user.ratings = user.ratings.filter(r => r.movieId !== movieId);
      
      // Add new rating
      user.ratings.push({ movieId, rating });
      
      await user.save();

      res.json({ message: 'Movie rated successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to rate movie', error: error.message });
    }
  }

  async addToWatchlist(req, res) {
    try {
      const { movieId } = req.body;
      const userId = req.userId;

      const user = await User.findById(userId);
      
      // Check if movie is already in watchlist
      const exists = user.watchlist.some(w => w.movieId === movieId);
      if (exists) {
        return res.status(400).json({ message: 'Movie already in watchlist' });
      }

      user.watchlist.push({ movieId });
      await user.save();

      res.json({ message: 'Movie added to watchlist' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to add to watchlist', error: error.message });
    }
  }

  async removeFromWatchlist(req, res) {
    try {
      const { movieId } = req.params;
      const userId = req.userId;

      const user = await User.findById(userId);
      user.watchlist = user.watchlist.filter(w => w.movieId !== parseInt(movieId));
      await user.save();

      res.json({ message: 'Movie removed from watchlist' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to remove from watchlist', error: error.message });
    }
  }

  async getWatchlist(req, res) {
    try {
      const userId = req.userId;
      const user = await User.findById(userId);
      
      const movieIds = user.watchlist.map(w => w.movieId);
      const movies = await Movie.find({ tmdbId: { $in: movieIds } });
      
      res.json(movies);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get watchlist', error: error.message });
    }
  }
}

module.exports = new MovieController();
