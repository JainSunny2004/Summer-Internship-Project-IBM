const recommendationService = require('../services/recommendationService');

class RecommendationController {
  async getRecommendations(req, res) {
    try {
      const userId = req.userId;
      const { method = 'hybrid', limit = 20 } = req.query;

      let recommendations;

      switch (method) {
        case 'user-based':
          recommendations = await recommendationService.getUserBasedRecommendations(userId, limit);
          break;
        case 'item-based':
          recommendations = await recommendationService.getItemBasedRecommendations(userId, limit);
          break;
        case 'content-based':
          recommendations = await recommendationService.getContentBasedRecommendations(userId, limit);
          break;
        case 'hybrid':
        default:
          recommendations = await recommendationService.getHybridRecommendations(userId, limit);
          break;
      }

      res.json({
        method,
        recommendations,
        count: recommendations.length,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to get recommendations', error: error.message });
    }
  }

  async getPersonalizedRecommendations(req, res) {
    try {
      const userId = req.userId;
      const { preferences } = req.body;

      // Update user preferences if provided
      if (preferences) {
        await User.findByIdAndUpdate(userId, { preferences });
      }

      const recommendations = await recommendationService.getHybridRecommendations(userId, 20);

      res.json({
        recommendations,
        message: 'Personalized recommendations generated successfully',
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to get personalized recommendations', error: error.message });
    }
  }
}

module.exports = new RecommendationController();
