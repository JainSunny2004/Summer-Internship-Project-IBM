const tmdbClient = require('../../config/tmdb');
const Movie = require('../models/Movie');

class TMDBService {
  async searchMovies(query, page = 1) {
    try {
      const response = await tmdbClient.get('/search/movie', {
        params: { query, page },
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to search movies from TMDB');
    }
  }

  async getMovieDetails(movieId) {
    try {
      const response = await tmdbClient.get(`/movie/${movieId}`, {
        params: {
          append_to_response: 'credits,keywords,similar',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to fetch movie details from TMDB');
    }
  }

  async getPopularMovies(page = 1) {
    try {
      const response = await tmdbClient.get('/movie/popular', {
        params: { page },
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to fetch popular movies from TMDB');
    }
  }

  async getMoviesByGenre(genreId, page = 1) {
    try {
      const response = await tmdbClient.get('/discover/movie', {
        params: {
          with_genres: genreId,
          page,
          sort_by: 'vote_average.desc',
          'vote_count.gte': 100,
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to fetch movies by genre from TMDB');
    }
  }

  async getGenres() {
    try {
      const response = await tmdbClient.get('/genre/movie/list');
      return response.data.genres;
    } catch (error) {
      throw new Error('Failed to fetch genres from TMDB');
    }
  }

  async saveMovieToDatabase(tmdbMovieData) {
    try {
      const existingMovie = await Movie.findOne({ tmdbId: tmdbMovieData.id });
      if (existingMovie) {
        return existingMovie;
      }

      const movieData = {
        tmdbId: tmdbMovieData.id,
        title: tmdbMovieData.title,
        overview: tmdbMovieData.overview,
        releaseDate: new Date(tmdbMovieData.release_date),
        genres: tmdbMovieData.genres?.map(g => g.id) || [],
        cast: tmdbMovieData.credits?.cast?.slice(0, 10).map(actor => ({
          id: actor.id,
          name: actor.name,
          character: actor.character,
        })) || [],
        crew: tmdbMovieData.credits?.crew?.filter(person => person.job === 'Director').map(director => ({
          id: director.id,
          name: director.name,
          job: director.job,
        })) || [],
        voteAverage: tmdbMovieData.vote_average,
        voteCount: tmdbMovieData.vote_count,
        popularity: tmdbMovieData.popularity,
        posterPath: tmdbMovieData.poster_path,
        backdropPath: tmdbMovieData.backdrop_path,
        runtime: tmdbMovieData.runtime,
        tagline: tmdbMovieData.tagline,
        budget: tmdbMovieData.budget,
        revenue: tmdbMovieData.revenue,
        spokenLanguages: tmdbMovieData.spoken_languages?.map(lang => lang.english_name) || [],
        productionCountries: tmdbMovieData.production_countries?.map(country => country.name) || [],
        keywords: tmdbMovieData.keywords?.keywords?.map(keyword => keyword.name) || [],
      };

      const movie = new Movie(movieData);
      await movie.save();
      return movie;
    } catch (error) {
      throw new Error('Failed to save movie to database');
    }
  }
}

module.exports = new TMDBService();
