const User = require('../models/User');
const Movie = require('../models/Movie');
const tmdbService = require('./tmdbService');

class RecommendationService {
  // User-based collaborative filtering
  async getUserBasedRecommendations(userId, limit = 10) {
    try {
      const user = await User.findById(userId);
      if (!user) throw new Error('User not found');

      // Find similar users based on rating patterns
      const similarUsers = await this.findSimilarUsers(userId);
      
      // Get movies rated highly by similar users
      const recommendations = new Map();
      
      for (const similarUser of similarUsers) {
        const userRatings = await User.findById(similarUser.userId).select('ratings');
        
        for (const rating of userRatings.ratings) {
          if (rating.rating >= 4 && !user.ratings.some(r => r.movieId === rating.movieId)) {
            const score = recommendations.get(rating.movieId) || 0;
            recommendations.set(rating.movieId, score + (rating.rating * similarUser.similarity));
          }
        }
      }

      // Sort by score and return top recommendations
      const sortedRecommendations = Array.from(recommendations.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, limit);

      return await this.getMovieDetails(sortedRecommendations.map(([movieId]) => movieId));
    } catch (error) {
      throw new Error('Failed to generate user-based recommendations');
    }
  }

  // Item-based collaborative filtering
  async getItemBasedRecommendations(userId, limit = 10) {
    try {
      const user = await User.findById(userId);
      if (!user) throw new Error('User not found');

      const userRatedMovies = user.ratings.filter(r => r.rating >= 4);
      const recommendations = new Map();

      for (const ratedMovie of userRatedMovies) {
        const similarMovies = await this.findSimilarMovies(ratedMovie.movieId);
        
        for (const similarMovie of similarMovies) {
          if (!user.ratings.some(r => r.movieId === similarMovie.movieId)) {
            const score = recommendations.get(similarMovie.movieId) || 0;
            recommendations.set(similarMovie.movieId, score + (ratedMovie.rating * similarMovie.similarity));
          }
        }
      }

      const sortedRecommendations = Array.from(recommendations.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, limit);

      return await this.getMovieDetails(sortedRecommendations.map(([movieId]) => movieId));
    } catch (error) {
      throw new Error('Failed to generate item-based recommendations');
    }
  }

  // Hybrid recommendation combining both methods
  async getHybridRecommendations(userId, limit = 20) {
    try {
      const [userBased, itemBased] = await Promise.all([
        this.getUserBasedRecommendations(userId, limit),
        this.getItemBasedRecommendations(userId, limit),
      ]);

      // Combine and deduplicate recommendations
      const combinedRecommendations = new Map();
      
      userBased.forEach(movie => {
        combinedRecommendations.set(movie.tmdbId, { ...movie, score: 0.6 });
      });

      itemBased.forEach(movie => {
        if (combinedRecommendations.has(movie.tmdbId)) {
          const existing = combinedRecommendations.get(movie.tmdbId);
          existing.score += 0.4;
        } else {
          combinedRecommendations.set(movie.tmdbId, { ...movie, score: 0.4 });
        }
      });

      // Add content-based recommendations
      const contentBased = await this.getContentBasedRecommendations(userId, limit / 2);
      contentBased.forEach(movie => {
        if (combinedRecommendations.has(movie.tmdbId)) {
          const existing = combinedRecommendations.get(movie.tmdbId);
          existing.score += 0.3;
        } else {
          combinedRecommendations.set(movie.tmdbId, { ...movie, score: 0.3 });
        }
      });

      return Array.from(combinedRecommendations.values())
        .sort((a, b) => b.score - a.score)
        .slice(0, limit);
    } catch (error) {
      throw new Error('Failed to generate hybrid recommendations');
    }
  }

  // Content-based filtering
  async getContentBasedRecommendations(userId, limit = 10) {
    try {
      const user = await User.findById(userId);
      if (!user) throw new Error('User not found');

      const userPreferences = await this.analyzeUserPreferences(userId);
      
      const movies = await Movie.find({
        $or: [
          { genres: { $in: userPreferences.favoriteGenres } },
          { 'cast.id': { $in: userPreferences.favoriteActors } },
          { 'crew.id': { $in: userPreferences.favoriteDirectors } },
        ],
        tmdbId: { $nin: user.ratings.map(r => r.movieId) },
      })
      .sort({ voteAverage: -1, popularity: -1 })
      .limit(limit);

      return movies;
    } catch (error) {
      throw new Error('Failed to generate content-based recommendations');
    }
  }

  async findSimilarUsers(userId) {
    try {
      const user = await User.findById(userId);
      const allUsers = await User.find({ _id: { $ne: userId } });
      
      const similarities = [];
      
      for (const otherUser of allUsers) {
        const similarity = this.calculateUserSimilarity(user.ratings, otherUser.ratings);
        if (similarity > 0.3) {
          similarities.push({
            userId: otherUser._id,
            similarity,
          });
        }
      }
      
      return similarities.sort((a, b) => b.similarity - a.similarity).slice(0, 10);
    } catch (error) {
      throw new Error('Failed to find similar users');
    }
  }

  async findSimilarMovies(movieId) {
    try {
      const movie = await Movie.findOne({ tmdbId: movieId });
      if (!movie) return [];

      const similarMovies = await Movie.find({
        $or: [
          { genres: { $in: movie.genres } },
          { 'cast.id': { $in: movie.cast.map(c => c.id) } },
          { 'crew.id': { $in: movie.crew.map(c => c.id) } },
        ],
        tmdbId: { $ne: movieId },
      }).limit(20);

      return similarMovies.map(similarMovie => ({
        movieId: similarMovie.tmdbId,
        similarity: this.calculateMovieSimilarity(movie, similarMovie),
      })).filter(item => item.similarity > 0.2);
    } catch (error) {
      throw new Error('Failed to find similar movies');
    }
  }

  calculateUserSimilarity(ratings1, ratings2) {
    const commonMovies = ratings1.filter(r1 => 
      ratings2.some(r2 => r2.movieId === r1.movieId)
    );
    
    if (commonMovies.length === 0) return 0;
    
    let sum1 = 0, sum2 = 0, sum1Sq = 0, sum2Sq = 0, pSum = 0;
    
    for (const rating1 of commonMovies) {
      const rating2 = ratings2.find(r => r.movieId === rating1.movieId);
      
      sum1 += rating1.rating;
      sum2 += rating2.rating;
      sum1Sq += Math.pow(rating1.rating, 2);
      sum2Sq += Math.pow(rating2.rating, 2);
      pSum += rating1.rating * rating2.rating;
    }
    
    const num = pSum - (sum1 * sum2 / commonMovies.length);
    const den = Math.sqrt((sum1Sq - Math.pow(sum1, 2) / commonMovies.length) * 
                         (sum2Sq - Math.pow(sum2, 2) / commonMovies.length));
    
    return den === 0 ? 0 : num / den;
  }

  calculateMovieSimilarity(movie1, movie2) {
    let similarity = 0;
    
    // Genre similarity
    const commonGenres = movie1.genres.filter(g => movie2.genres.includes(g));
    const genreSimilarity = commonGenres.length / Math.max(movie1.genres.length, movie2.genres.length);
    similarity += genreSimilarity * 0.4;
    
    // Cast similarity
    const commonCast = movie1.cast.filter(c1 => movie2.cast.some(c2 => c2.id === c1.id));
    const castSimilarity = commonCast.length / Math.max(movie1.cast.length, movie2.cast.length);
    similarity += castSimilarity * 0.3;
    
    // Director similarity
    const commonDirectors = movie1.crew.filter(c1 => 
      movie2.crew.some(c2 => c2.id === c1.id && c2.job === 'Director')
    );
    const directorSimilarity = commonDirectors.length > 0 ? 1 : 0;
    similarity += directorSimilarity * 0.3;
    
    return similarity;
  }

  async analyzeUserPreferences(userId) {
    try {
      const user = await User.findById(userId);
      const highRatedMovies = await Movie.find({
        tmdbId: { $in: user.ratings.filter(r => r.rating >= 4).map(r => r.movieId) }
      });

      const genreCount = {};
      const actorCount = {};
      const directorCount = {};

      for (const movie of highRatedMovies) {
        movie.genres.forEach(genre => {
          genreCount[genre] = (genreCount[genre] || 0) + 1;
        });
        
        movie.cast.forEach(actor => {
          actorCount[actor.id] = (actorCount[actor.id] || 0) + 1;
        });
        
        movie.crew.forEach(person => {
          if (person.job === 'Director') {
            directorCount[person.id] = (directorCount[person.id] || 0) + 1;
          }
        });
      }

      return {
        favoriteGenres: Object.keys(genreCount).sort((a, b) => genreCount[b] - genreCount[a]).slice(0, 5).map(Number),
        favoriteActors: Object.keys(actorCount).sort((a, b) => actorCount[b] - actorCount[a]).slice(0, 10).map(Number),
        favoriteDirectors: Object.keys(directorCount).sort((a, b) => directorCount[b] - directorCount[a]).slice(0, 5).map(Number),
      };
    } catch (error) {
      throw new Error('Failed to analyze user preferences');
    }
  }

  async getMovieDetails(movieIds) {
    try {
      const movies = await Movie.find({ tmdbId: { $in: movieIds } });
      return movies;
    } catch (error) {
      throw new Error('Failed to get movie details');
    }
  }
}

module.exports = new RecommendationService();
