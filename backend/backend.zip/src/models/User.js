const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  password: {
    type: String,
    required: true,
  },
  preferences: {
    favoriteGenres: [{ type: Number }],
    favoriteActors: [{ type: Number }],
    favoriteDirectors: [{ type: Number }],
  },
  ratings: [{
    movieId: { type: Number, required: true },
    rating: { type: Number, required: true, min: 1, max: 5 },
    timestamp: { type: Date, default: Date.now },
  }],
  watchlist: [{
    movieId: { type: Number, required: true },
    addedAt: { type: Date, default: Date.now },
  }],
  watchHistory: [{
    movieId: { type: Number, required: true },
    watchedAt: { type: Date, default: Date.now },
  }],
}, {
  timestamps: true,
});

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
