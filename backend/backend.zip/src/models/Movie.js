const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
  tmdbId: {
    type: Number,
    required: true,
    unique: true,
  },
  title: {
    type: String,
    required: true,
  },
  overview: String,
  releaseDate: Date,
  genres: [{ type: Number }],
  cast: [{
    id: Number,
    name: String,
    character: String,
  }],
  crew: [{
    id: Number,
    name: String,
    job: String,
  }],
  voteAverage: Number,
  voteCount: Number,
  popularity: Number,
  posterPath: String,
  backdropPath: String,
  runtime: Number,
  tagline: String,
  budget: Number,
  revenue: Number,
  spokenLanguages: [String],
  productionCountries: [String],
  keywords: [String],
  lastUpdated: {
    type: Date,
    default: Date.now,
  },
}, {
  timestamps: true,
});

movieSchema.index({ tmdbId: 1 });
movieSchema.index({ genres: 1 });
movieSchema.index({ voteAverage: -1 });
movieSchema.index({ popularity: -1 });

module.exports = mongoose.model('Movie', movieSchema);
