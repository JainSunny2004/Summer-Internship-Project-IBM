const express = require('express');
const { body } = require('express-validator');
const authController = require('../controllers/authController');
const auth = require('../utils/auth');

const router = express.Router();

router.post('/register', [
  body('username').isLength({ min: 3 }).trim(),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
], authController.register);

router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').exists(),
], authController.login);

router.get('/profile', auth, authController.getProfile);

module.exports = router;
