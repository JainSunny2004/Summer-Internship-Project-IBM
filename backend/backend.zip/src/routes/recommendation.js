const express = require('express');
const router = express.Router();
const { recommendMovies } = require('../controllers/recommendationController');

// POST /api/recommend
router.post('/', recommendMovies);

module.exports = router;
