const express = require('express');
const { body } = require('express-validator');
const movieController = require('../controllers/movieController');
const auth = require('../utils/auth');

const router = express.Router();

router.get('/search', movieController.searchMovies);
router.get('/popular', movieController.getPopularMovies);
router.get('/genres', movieController.getGenres);
router.get('/genre/:genreId', movieController.getMoviesByGenre);
router.get('/:id', movieController.getMovieDetails);

// Protected routes
router.post('/rate', auth, [
  body('movieId').isNumeric(),
  body('rating').isInt({ min: 1, max: 5 }),
], movieController.rateMovie);

router.post('/watchlist', auth, movieController.addToWatchlist);
router.delete('/watchlist/:movieId', auth, movieController.removeFromWatchlist);
router.get('/user/watchlist', auth, movieController.getWatchlist);

module.exports = router;
