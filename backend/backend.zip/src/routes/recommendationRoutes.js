const express = require('express');
const recommendationController = require('../controllers/recommendationController');
const auth = require('../utils/auth');

const router = express.Router();

router.get('/', auth, recommendationController.getRecommendations);
router.post('/personalized', auth, recommendationController.getPersonalizedRecommendations);

module.exports = router;
