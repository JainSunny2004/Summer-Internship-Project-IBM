import api from './api';

export const recommendationService = {
  getRecommendations: async (method = 'hybrid', limit = 20) => {
    const response = await api.get(`/recommendations?method=${method}&limit=${limit}`);
    return response.data;
  },

  getPersonalizedRecommendations: async (preferences) => {
    const response = await api.post('/recommendations/personalized', { preferences });
    return response.data;
  },
};
