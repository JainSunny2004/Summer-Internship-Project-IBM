import api from './api';

export const movieService = {
  searchMovies: async (query, page = 1) => {
    const response = await api.get(`/movies/search?query=${query}&page=${page}`);
    return response.data;
  },

  getMovieDetails: async (id) => {
    const response = await api.get(`/movies/${id}`);
    return response.data;
  },

  getPopularMovies: async (page = 1) => {
    const response = await api.get(`/movies/popular?page=${page}`);
    return response.data;
  },

  getMoviesByGenre: async (genreId, page = 1) => {
    const response = await api.get(`/movies/genre/${genreId}?page=${page}`);
    return response.data;
  },

  getGenres: async () => {
    const response = await api.get('/movies/genres');
    return response.data;
  },

  rateMovie: async (movieId, rating) => {
    const response = await api.post('/movies/rate', { movieId, rating });
    return response.data;
  },

  addToWatchlist: async (movieId) => {
    const response = await api.post('/movies/watchlist', { movieId });
    return response.data;
  },

  removeFromWatchlist: async (movieId) => {
    const response = await api.delete(`/movies/watchlist/${movieId}`);
    return response.data;
  },

  getWatchlist: async () => {
    const response = await api.get('/movies/user/watchlist');
    return response.data;
  },
};
