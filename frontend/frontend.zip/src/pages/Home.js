import React, { useState, useEffect } from 'react';
import { useQuery } from 'react-query';
import MovieCard from '../components/MovieCard';
import SearchBar from '../components/SearchBar';
import GenreFilter from '../components/GenreFilter';
import { movieService } from '../services/movieService';
import { recommendationService } from '../services/recommendationService';

const Home = () => {
  const [searchResults, setSearchResults] = useState([]);
  const [selectedGenres, setSelectedGenres] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  const { data: popularMovies, isLoading: popularLoading } = useQuery(
    'popularMovies',
    () => movieService.getPopularMovies(),
    { staleTime: 5 * 60 * 1000 }
  );

  const { data: recommendations, isLoading: recommendationsLoading } = useQuery(
    'recommendations',
    () => recommendationService.getRecommendations('hybrid', 12),
    { staleTime: 10 * 60 * 1000 }
  );

  const handleSearch = async (query) => {
    setIsSearching(true);
    try {
      const results = await movieService.searchMovies(query);
      setSearchResults(results.results);
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const handleGenreFilter = async (genres) => {
    setSelectedGenres(genres);
    if (genres.length > 0) {
      // For simplicity, filter by first selected genre
      try {
        const results = await movieService.getMoviesByGenre(genres[0]);
        setSearchResults(results.results);
      } catch (error) {
        console.error('Genre filter failed:', error);
      }
    } else {
      setSearchResults([]);
    }
  };

  const displayMovies = searchResults.length > 0 ? searchResults : popularMovies?.results || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Discover Your Next Favorite Movie
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Get personalized recommendations based on your preferences
          </p>
          
          <div className="max-w-2xl mx-auto">
            <SearchBar onSearch={handleSearch} />
          </div>
        </div>

        <GenreFilter 
          selectedGenres={selectedGenres} 
          onGenreChange={handleGenreFilter}
        />

        {/* Recommendations Section */}
        {!isSearching && searchResults.length === 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">Recommended for You</h2>
            {recommendationsLoading ? (
              <div className="text-center py-8">Loading recommendations...</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {recommendations?.recommendations?.slice(0, 8).map((movie) => (
                  <MovieCard key={movie.tmdbId} movie={movie} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Popular/Search Results Section */}
        <div>
          <h2 className="text-2xl font-bold mb-6">
            {searchResults.length > 0 ? 'Search Results' : 'Popular Movies'}
          </h2>
          
          {(isSearching || popularLoading) ? (
            <div className="text-center py-8">Loading...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {displayMovies.map((movie) => (
                <MovieCard key={movie.id || movie.tmdbId} movie={movie} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;
