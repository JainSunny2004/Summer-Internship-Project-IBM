import React, { useState } from 'react';
import { useQuery } from 'react-query';
import MovieCard from '../components/MovieCard';
import RecommendationSettings from '../components/RecommendationSettings';
import { recommendationService } from '../services/recommendationService';

const Recommendations = () => {
  const [settings, setSettings] = useState({ method: 'hybrid', limit: 20 });

  const { data: recommendations, isLoading, refetch } = useQuery(
    ['recommendations', settings],
    () => recommendationService.getRecommendations(settings.method, settings.limit),
    { staleTime: 5 * 60 * 1000 }
  );

  const handleSettingsChange = (newSettings) => {
    setSettings(newSettings);
  };

  const getMethodDescription = (method) => {
    switch (method) {
      case 'user-based':
        return 'Based on users with similar preferences';
      case 'item-based':
        return 'Based on movies similar to ones you liked';
      case 'content-based':
        return 'Based on movie features you prefer';
      case 'hybrid':
        return 'Combines multiple recommendation techniques';
      default:
        return '';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Your Recommendations
            </h1>
            <p className="text-gray-600">
              {getMethodDescription(settings.method)}
            </p>
          </div>
          <RecommendationSettings onSettingsChange={handleSettingsChange} />
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
            <p className="mt-4 text-gray-600">Generating recommendations...</p>
          </div>
        ) : (
          <>
            <div className="bg-white rounded-lg p-6 mb-8 shadow-sm">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-lg font-semibold">
                    {recommendations?.recommendations?.length || 0} movies found
                  </h2>
                  <p className="text-sm text-gray-600">
                    Method: {settings.method} | Updated just now
                  </p>
                </div>
                <button
                  onClick={() => refetch()}
                  className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors"
                >
                  Refresh
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {recommendations?.recommendations?.map((movie) => (
                <MovieCard key={movie.tmdbId} movie={movie} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Recommendations;
