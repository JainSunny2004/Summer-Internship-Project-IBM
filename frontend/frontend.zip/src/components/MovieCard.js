import React, { useState } from 'react';
import { Star, Plus, Check, Eye } from 'lucide-react';
import { movieService } from '../services/movieService';
import toast from 'react-hot-toast';

const MovieCard = ({ movie, onRate, onWatchlist }) => {
  const [rating, setRating] = useState(0);
  const [isInWatchlist, setIsInWatchlist] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleRate = async (newRating) => {
    try {
      setIsLoading(true);
      await movieService.rateMovie(movie.tmdbId, newRating);
      setRating(newRating);
      toast.success('Movie rated successfully!');
      onRate && onRate(movie.tmdbId, newRating);
    } catch (error) {
      toast.error('Failed to rate movie');
    } finally {
      setIsLoading(false);
    }
  };

  const handleWatchlist = async () => {
    try {
      setIsLoading(true);
      if (isInWatchlist) {
        await movieService.removeFromWatchlist(movie.tmdbId);
        setIsInWatchlist(false);
        toast.success('Removed from watchlist');
      } else {
        await movieService.addToWatchlist(movie.tmdbId);
        setIsInWatchlist(true);
        toast.success('Added to watchlist');
      }
      onWatchlist && onWatchlist(movie.tmdbId, !isInWatchlist);
    } catch (error) {
      toast.error('Failed to update watchlist');
    } finally {
      setIsLoading(false);
    }
  };

  const posterUrl = movie.posterPath 
    ? `https://image.tmdb.org/t/p/w500${movie.posterPath}`
    : '/placeholder-movie.jpg';

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <img
          src={posterUrl}
          alt={movie.title}
          className="w-full h-64 object-cover"
        />
        <div className="absolute top-2 right-2 flex gap-2">
          <button
            onClick={handleWatchlist}
            disabled={isLoading}
            className={`p-2 rounded-full ${
              isInWatchlist 
                ? 'bg-green-500 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-100'
            } transition-colors`}
          >
            {isInWatchlist ? <Check size={16} /> : <Plus size={16} />}
          </button>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2 truncate">{movie.title}</h3>
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{movie.overview}</p>
        
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1">
            <Star className="text-yellow-500 fill-current" size={16} />
            <span className="text-sm font-medium">{movie.voteAverage?.toFixed(1)}</span>
          </div>
          <span className="text-sm text-gray-500">
            {new Date(movie.releaseDate).getFullYear()}
          </span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => handleRate(star)}
                disabled={isLoading}
                className={`p-1 ${
                  star <= rating ? 'text-yellow-500' : 'text-gray-300'
                } hover:text-yellow-500 transition-colors`}
              >
                <Star size={16} fill={star <= rating ? 'currentColor' : 'none'} />
              </button>
            ))}
          </div>
          
          <button className="text-blue-500 hover:text-blue-600 transition-colors">
            <Eye size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
