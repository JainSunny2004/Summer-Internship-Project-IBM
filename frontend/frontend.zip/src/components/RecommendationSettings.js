import React, { useState } from 'react';
import { Settings } from 'lucide-react';

const RecommendationSettings = ({ onSettingsChange }) => {
  const [method, setMethod] = useState('hybrid');
  const [limit, setLimit] = useState(20);
  const [showSettings, setShowSettings] = useState(false);

  const handleApplySettings = () => {
    onSettingsChange({ method, limit });
    setShowSettings(false);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setShowSettings(!showSettings)}
        className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
      >
        <Settings size={16} />
        Settings
      </button>

      {showSettings && (
        <div className="absolute right-0 top-12 bg-white border rounded-lg shadow-lg p-4 w-80 z-10">
          <h3 className="font-semibold mb-4">Recommendation Settings</h3>
          
          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">Method</label>
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md"
            >
              <option value="hybrid">Hybrid (Recommended)</option>
              <option value="user-based">User-Based Collaborative</option>
              <option value="item-based">Item-Based Collaborative</option>
              <option value="content-based">Content-Based</option>
            </select>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">Number of Recommendations</label>
            <input
              type="range"
              min="10"
              max="50"
              value={limit}
              onChange={(e) => setLimit(parseInt(e.target.value))}
              className="w-full"
            />
            <span className="text-sm text-gray-500">{limit} movies</span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleApplySettings}
              className="flex-1 bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition-colors"
            >
              Apply
            </button>
            <button
              onClick={() => setShowSettings(false)}
              className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-md hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default RecommendationSettings;
